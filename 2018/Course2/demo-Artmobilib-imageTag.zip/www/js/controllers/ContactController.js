angular.module('artmobilis').controller('ContactController',
  ['$scope',
    function (
      $scope
      ) {
        

    }]);