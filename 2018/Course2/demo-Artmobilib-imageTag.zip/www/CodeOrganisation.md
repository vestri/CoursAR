#How this work ?

##Folder organisation
###[css](css)
Here you will found all the ... css styles...
don't forget to put the extra libs one (and link then nicely)!

[Ionic css Components](http://ionicframework.com/docs/components) (header / list / button / cards ...)

ArtMobilis css file style is [__style.css__](css/styles.css) !
###[img](img)

* [dump](dump)
* [icones](icones)
* [trained](trained)
* [vignettes](vignettes)

###[js](js)

* [controllers](controllers)
* [directives](directives)
* [services](services)

###[lib](lib)
All the external libs (angular.js / aruco / glfx / ionic / jsjeat / lealfet / threejs / ...)

###[merges](merges)
###[res](res)
###[scripts](scripts)
###[templates](templates)
###[video](video)
